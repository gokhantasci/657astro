// injector.js — hook fetch & XHR in MAIN world
(function(){
  function post(payload, src){ try{ window.postMessage({__UYAP_JSON_HIT__:true, payload, src}, "*"); }catch(e){} }
  // fetch
  try{
    const _f = window.fetch.bind(window);
    window.fetch = async function(input, init){
      const res = await _f(input, init);
      try{
        const url = typeof input==="string" ? input : input?.url;
        if(url && /davaDosyaSorgula/i.test(url)){
          const c = res.clone(); const ct = c.headers.get("content-type")||"";
          if(ct.includes("application/json")){
            const data = await c.json(); if(data && (Array.isArray(data.data)||data.data)) post(data,"page-fetch");
          }
        }
      }catch(_){}
      return res;
    };
  }catch(_){}
  // XHR
  try{
    const X=window.XMLHttpRequest; const open=X.prototype.open; const send=X.prototype.send;
    X.prototype.open=function(m,u){ this.__isUyapHit = u && /davaDosyaSorgula/i.test(u); return open.apply(this, arguments); };
    X.prototype.send=function(){ if(this.__isUyapHit){ this.addEventListener("readystatechange",()=>{ if(this.readyState===4){ try{
      const ct=this.getResponseHeader?.("content-type")||""; if(ct.includes("application/json")){ try{ const j=JSON.parse(this.responseText); if(j && (Array.isArray(j.data)||j.data)) post(j,"page-xhr"); }catch(_){ } }
    }catch(_){ } } }); } return send.apply(this, arguments); };
  }catch(_){}
  console.debug("[UYAP JSON] injector aktif.");
})();