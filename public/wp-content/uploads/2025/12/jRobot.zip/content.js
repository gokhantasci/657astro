// content.js — v18.3 (guarded messaging)
(function(){
  function safeSend(m){ try{ if(chrome?.runtime?.id){ chrome.runtime.sendMessage(m).catch?.(()=>{}); } }catch(_){ } }
  // request injector once
  let asked=false; const ensure=()=>{ if(asked) return; asked=true; safeSend({action:"injectMain"}); };
  ensure(); document.addEventListener("visibilitychange", ()=>{ if(document.visibilityState==="visible") ensure(); });
  // bridge page -> ext
  window.addEventListener("message",(ev)=>{ const d=ev.data; if(d&&d.__UYAP_JSON_HIT__&&d.payload){ safeSend({action:"payloadFromPage",payload:d.payload,src:d.src||"page"}); } },false);
})();