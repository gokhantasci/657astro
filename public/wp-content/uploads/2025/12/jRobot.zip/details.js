const RKEY = "json_stats_rows";

let rows = [];
let meta = null;
let table = null;

(function ensureTheme() {
  if (window.setTheme) {
    window.setTheme(localStorage.getItem("uyap_theme") || "dark");
  } else {
    const t = localStorage.getItem("uyap_theme") || "dark";
    document.documentElement.setAttribute("data-theme", t);
  }
})();

function exportWithButtons(headers, rows, filename = "export.xlsx", sheetName = "Export") {
  const wrapper = document.createElement("div");
  wrapper.style.position = "fixed";
  wrapper.style.left = "-9999px";
  const table = document.createElement("table");
  const id = `tmpExport_${Date.now()}`;
  table.id = id;
  wrapper.appendChild(table);
  document.body.appendChild(wrapper);

  const dt = new DataTable(`#${id}`, {
    data: rows,
    columns: headers.map(h => ({ title: h.title || h, data: h.key || h })),
    paging: false,
    searching: false,
    info: false,
    ordering: false,
    dom: "B",
    buttons: [{
      extend: "excelHtml5",
      title: sheetName,
      filename: filename.replace(/\.xlsx$/i, ""),
      exportOptions: { columns: headers.map((_, i) => i) }
    }]
  });

  dt.button(0).trigger();
  setTimeout(() => {
    try { dt.destroy(true); } catch (_) {}
    wrapper.remove();
  }, 1000);
}

(function ensureTheme() {
  if (window.setTheme) {
    window.setTheme(localStorage.getItem("uyap_theme") || "dark");
  } else {
    const t = localStorage.getItem("uyap_theme") || "dark";
    document.documentElement.setAttribute("data-theme", t);
  }
})();

const DT_LANG = {
  emptyTable: "Gösterilecek veri yok",
  info: "_TOTAL_ kayıttan _START_ - _END_ arası",
  infoEmpty: "Kayıt yok",
  infoFiltered: "(_MAX_ kayıt içinden süzüldü)",
  lengthMenu: "_MENU_ satır göster",
  loadingRecords: "Yükleniyor...",
  processing: "İşleniyor...",
  search: "Ara",
  zeroRecords: "Eşleşen kayıt bulunamadı",
  paginate: { first: "İlk", last: "Son", next: "Sonraki", previous: "Önceki" }
};

function fmtDate(v) {
  if (!v) return "";
  try {
    const d = new Date(v);
    if (isNaN(d)) return v;
    const dd = String(d.getDate()).padStart(2, "0");
    const mm = String(d.getMonth() + 1).padStart(2, "0");
    const yy = d.getFullYear();
    return `${dd}.${mm}.${yy}`;
  } catch (e) {
    return v;
  }
}

function buildFileName() {
  let fname = "detaylar";
  if (meta?.type) fname += `-${meta.type}`;
  if (meta?.id) fname += `-${meta.id}`;
  if (meta?.filters && (meta.filters.kararFrom || meta.filters.kararTo)) {
    const k1 = meta.filters.kararFrom || "";
    const k2 = meta.filters.kararTo   || "";
    fname += "-" + [k1, k2].filter(Boolean).join("_");
  }
  return `${fname}.xlsx`;
}

function renderMeta() {
  const metaEl = document.getElementById("metaInfo");
  if (!metaEl || !meta) return;

  const tags = [];
  if (meta.type) tags.push(`Tip: ${meta.type}`);
  if (meta.id) tags.push(`ID: ${meta.id}`);
  if (meta.unit) tags.push(`Birim: ${meta.unit}`);
  if (meta.filters?.kararFrom || meta.filters?.kararTo) {
    tags.push(`Karar: ${meta.filters.kararFrom || "…"} → ${meta.filters.kararTo || "…"}`);
  }
  if (meta.filters?.acilisFrom || meta.filters?.acilisTo) {
    tags.push(`Açılış: ${meta.filters.acilisFrom || "…"} → ${meta.filters.acilisTo || "…"}`);
  }

  metaEl.innerHTML = tags.map(t => `<span class="tag">${t}</span>`).join("");
}

function renderTable() {
  const data = rows.map((r, idx) => {
    const kapanis = r.dosyaKapanisTarihi || r.kapanisTarihi || null;
    return {
      index: idx + 1,
      esasNo: r.dosyaNo || r.esasNo || "",
      kararNo: r.kararNo || "",
      acilis: fmtDate(r.dosyaAcilisTarihi),
      karar: fmtDate(r.kararTarihi),
      kapanis: fmtDate(kapanis)
    };
  });

  if (table) {
    table.clear();
    table.rows.add(data);
    table.draw();
    return;
  }

  table = new DataTable("#tbl", {
    data,
    columns: [
      { title: "#", data: "index", className: "mono text-end" },
      { title: "Esas No", data: "esasNo", className: "mono" },
      { title: "Karar No", data: "kararNo", className: "mono" },
      { title: "Açılış", data: "acilis", className: "mono" },
      { title: "Karar", data: "karar", className: "mono" },
      { title: "Kapanış", data: "kapanis", className: "mono" }
    ],
    pageLength: 25,
    responsive: true,
    language: DT_LANG,
    columnDefs: [{ targets: "_all", className: "dt-center" }],
    layout: {
      topEnd: "search",
      bottomStart: "info",
      bottomEnd: "paging"
    }
  });
}

document.getElementById("exportAll").addEventListener("click", () => {
  if (!rows.length) {
    alert("İndirilecek kayıt yok.");
    return;
  }
  const headers = [
    { key: "birimAdi",              title: "Birim" },
    { key: "dosyaNo",               title: "Dosya / Esas" },
    { key: "kararNo",               title: "Karar No" },
    { key: "dosyaAcilisTarihi",     title: "Açılış" },
    { key: "kararTarihi",           title: "Karar" },
    { key: "dosyaKapanisTarihi",    title: "Kapanış" }
  ];

  const prepared = rows.map(r => ({
    birimAdi: r.birimAdi || "",
    dosyaNo: r.dosyaNo || r.esasNo || "",
    kararNo: r.kararNo || "",
    dosyaAcilisTarihi: fmtDate(r.dosyaAcilisTarihi),
    kararTarihi: fmtDate(r.kararTarihi),
    dosyaKapanisTarihi: fmtDate(r.dosyaKapanisTarihi || r.kapanisTarihi)
  }));

  exportWithButtons(headers, prepared, buildFileName(), "Detaylar");
});

chrome.storage.local.get(["detailKeys", "detailMeta", RKEY], d => {
  meta = d.detailMeta || null;
  const keys = d.detailKeys || [];
  const all  = d[RKEY] || [];

  const map = new Map();
  for (const r of all) {
    const k = r.dosyaNo || r.esasNo || null;
    if (k) map.set(String(k), r);
  }

rows = keys
  .map(k => map.get(String(k)))
  .filter(Boolean);

  document.getElementById("title").textContent =
    `Detaylar (${rows.length} kayıt)`;
  renderMeta();
  renderTable();
});
