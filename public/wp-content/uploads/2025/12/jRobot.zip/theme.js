(function initThemeImmediate() {
  const stored = (typeof localStorage !== "undefined")
    ? (localStorage.getItem("uyap_theme") || "dark")
    : "dark";
  document.documentElement.setAttribute("data-theme", stored);
})();

window.setTheme = function setTheme(theme) {
  const t = theme === "light" ? "light" : "dark";
  document.documentElement.setAttribute("data-theme", t);
  try { localStorage.setItem("uyap_theme", t); } catch (_) {}
  return t;
};
