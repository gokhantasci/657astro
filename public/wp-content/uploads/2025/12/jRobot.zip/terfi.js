const RKEY = "json_stats_rows";

(function ensureTheme(){
  if (window.setTheme) {
    window.setTheme(localStorage.getItem("uyap_theme") || "dark");
  } else {
    const t = localStorage.getItem("uyap_theme") || "dark";
    document.documentElement.setAttribute("data-theme", t);
  }
})();

function toTime(v) {
  if (!v) return null;
  const t = new Date(v).getTime();
  return Number.isFinite(t) ? t : null;
}

function fmtNum(n) {
  return new Intl.NumberFormat("tr-TR").format(n);
}

let lastOthersCount = 0;
let judgeOptionsLoaded = false;

async function loadJudges() {
  if (judgeOptionsLoaded) return;
  const sel = document.getElementById("judgeSelect");
  if (!sel) return;
  const st = await chrome.storage.local.get(RKEY);
  const rows = st[RKEY] || [];
  const set = new Set();
  for (const r of rows) {
    [r.hukumHakimBaskanPId, r.hukumUye1PId, r.hukumUye2PId].forEach(id => {
      if (id != null && String(id).trim()) set.add(String(id).trim());
    });
  }
  const options = Array.from(set).sort((a, b) => a.localeCompare(b, "tr-TR"));
  sel.innerHTML = `<option value="">Sicil seçin</option>` + options.map(id => `<option value="${id}">${id}</option>`).join("");
  judgeOptionsLoaded = true;
}

document.getElementById("btnRun").addEventListener("click", () => {
  const sicil = document.getElementById("judgeSelect").value.trim();
  const t1    = document.getElementById("tStart").value;
  const t2    = document.getElementById("tEnd").value;

  if (!sicil) {
    alert("Lütfen hakim sicil numarasını seçiniz.");
    return;
  }
  if (!t1 || !t2) {
    alert("Lütfen teftiş başlangıç ve bitiş tarihlerini giriniz.");
    return;
  }

  const start = new Date(t1).getTime();
  const end   = new Date(t2).getTime() + 86400000 - 1;

  if (!Number.isFinite(start) || !Number.isFinite(end) || start > end) {
    alert("Tarih aralığı geçerli değil.");
    return;
  }

  chrome.storage.local.get(RKEY, st => {
    const rows = st[RKEY] || [];
    const belongsToJudge = r =>
      [r.hukumHakimBaskanPId, r.hukumUye1PId, r.hukumUye2PId]
        .some(x => String(x) === sicil);

    let devreden = 0;
    let gelen    = 0;
    let cikan    = 0;

    const othersRows = [];

    for (const r of rows) {
      const ac  = toTime(r.dosyaAcilisTarihi);
      const kr  = toTime(r.kararTarihi);
      const kap = toTime(r.dosyaKapanisTarihi || r.kapanisTarihi);

      const isMine = belongsToJudge(r);

      if (isMine && ac != null && ac < start && (!kr || kr >= start)) {
        devreden++;
      }

      if (isMine && ac != null && ac >= start && ac <= end) {
        gelen++;
      }

      if (isMine && kr != null && kr >= start && kr <= end) {
        cikan++;
      }

      if (!isMine && kr != null && kr >= start && kr <= end) {
        othersRows.push({
          birimAdi: r.birimAdi || "",
          dosyaNo: r.dosyaNo || r.esasNo || "",
          kararNo: r.kararNo || "",
          acilis: r.dosyaAcilisTarihi || null,
          karar: r.kararTarihi || null,
          kapanis: r.dosyaKapanisTarihi || r.kapanisTarihi || null,
          hakimBaskan: r.hukumHakimBaskanPId || "",
          hakimUye1: r.hukumUye1PId || "",
          hakimUye2: r.hukumUye2PId || ""
        });
      }
    }

    const toplamBakilan = devreden + gelen;
    lastOthersCount = othersRows.length;

    chrome.storage.local.set({ terfiOthersRows: othersRows });

    const el = document.getElementById("result");
    const othersText = lastOthersCount
      ? `<a href="#" id="lnkOthers">${fmtNum(lastOthersCount)} adet dosya</a>`
      : "herhangi bir dosya";
    el.innerHTML = `
      <div><b>Hakim Sicili:</b> <span class="mono">${sicil}</span></div>
      <div><b>Teftiş Aralığı:</b> ${t1} - ${t2}</div>
      <hr/>
      <div><b>Devreden iş miktarı (X):</b> ${fmtNum(devreden)}</div>
      <div><b>Gelen iş miktarı (Y):</b> ${fmtNum(gelen)}</div>
      <div><b>Dönem içinde bakılan iş miktarı (X + Y):</b> ${fmtNum(toplamBakilan)}</div>
      <div><b>Çıkan iş miktarı (Z):</b> ${fmtNum(cikan)}</div>
      <hr/>
      <div><b>İzah:</b></div>
      <div style="margin-top:4px;">
        Teftiş aralığı içerisinde, karar tarihi bu aralıkta bulunan dosyalardan
        ${othersText}, forma girilen hakim sicilinden farklı hakim/hakimler
        tarafından çıkarılmış görünmektedir (Z toplamı içinde, forma girilmeyen
        veya farklı sicile ait hakimlere ait dosya sayısı).
      </div>
    `;
  });
});

document.getElementById("result").addEventListener("click", e => {
  const link = e.target.closest("#lnkOthers");
  if (!link) return;
  e.preventDefault();
  if (!lastOthersCount) return;

  chrome.windows.create({
    url: chrome.runtime.getURL("terfi_others.html"),
    type: "popup",
    width: 900,
    height: 720
  });
});

document.addEventListener("DOMContentLoaded", loadJudges);
