// background.js — v20.0 (güncel kayıt + birim istatistik)
// Storage key'leri
const KEY  = "json_stats";             // hook logları
const SKEY = "json_stats_aggregates";  // hakim/savcı/katip/statü özetleri
const RKEY = "json_stats_rows";        // ham satırlar

const R_CAP   = 100000;   // maksimum satır
const LOG_CAP = 200;      // en fazla 200 sayfa kaydı tutulur

// Basit path okuyucu (hukumHakimBaskanPId, statuBilgisi.aciklama vs.)
function pick(obj, path) {
  if (!obj || !path) return null;
  const parts = path.split(".");
  let cur = obj;
  for (const p of parts) {
    if (cur == null || typeof cur !== "object") return null;
    cur = cur[p];
  }
  return cur;
}

// Tekil anahtar: önce dosyaNo, yoksa esasNo
function getKeyFromRow(row) {
  return row?.dosyaNo || row?.esasNo || null;
}

// Özet istatistik üret
function buildAggregatesFromRows(rows) {
  const ag = {
    hakim: {},
    savci: {},
    katip: {},
    statu: {}
  };

  const inc = (map, key) => {
    if (key == null && key !== 0) return;
    const s = String(key).trim();
    if (!s) return;
    map[s] = (map[s] || 0) + 1;
  };

  for (const it of rows) {
    // Hakim/Başkan + Üyeler
    [
      pick(it, "hukumHakimBaskanPId"),
      pick(it, "hukumUye1PId"),
      pick(it, "hukumUye2PId")
    ].forEach(h => inc(ag.hakim, h));

    // Savcı
    inc(ag.savci, pick(it, "hukumSavciPId"));

    // Katip
    inc(ag.katip, pick(it, "hukumKatipPId"));

    // Statü
    const st =
      pick(it, "statuAcklm") ||
      pick(it, "statuBilgisi.aciklama") ||
      "—";
    inc(ag.statu, st);
  }

  return ag;
}

// Ana hook: sayfadaki payload'ı kaydet
async function push(payload, src) {
  const count = Array.isArray(payload?.data) ? payload.data.length : 0;

  // Mevcut durum
  const st   = await chrome.storage.local.get([KEY, SKEY, RKEY]);
  const list = st[KEY]  || [];
  const raw  = st[RKEY] || [];

  // Ham veriden tekil map oluştur (ilk geçen kayıt baz alınır)
  const byKey = new Map();
  const noKeyRows = [];

  for (const r of raw) {
    const key = getKeyFromRow(r);
    if (key) {
      if (!byKey.has(key)) byKey.set(key, r);
    } else {
      noKeyRows.push(r);
    }
  }

  let inserted = 0;
  let updated  = 0;

  const arr = Array.isArray(payload?.data) ? payload.data : [];

  // Yeni gelen satırlar: aynı anahtar varsa üstüne yaz (en güncel kalsın)
  for (const it of arr) {
    const key = getKeyFromRow(it);
    if (key) {
      if (byKey.has(key)) {
        updated++;
      } else {
        inserted++;
      }
      byKey.set(key, it);
    } else {
      // anahtarsız kayıtlar takip edilemiyor, hepsini yeni say
      inserted++;
      noKeyRows.push(it);
    }
  }

  // Map'teki tekil kayıtlar + anahtarsızlar
  let newRaw = Array.from(byKey.values()).concat(noKeyRows);

  // Kapasite aşılırsa en eskileri at
  if (newRaw.length > R_CAP) {
    newRaw = newRaw.slice(newRaw.length - R_CAP);
  }

  const total = newRaw.length;

  // Özet istatistikleri yeni ham listeden sıfırdan hesapla
  const ag = buildAggregatesFromRows(newRaw);

  // Log kaydı ekle (son LOG_CAP kayıt saklanır)
  list.push({
    ts: new Date().toISOString(),
    picked: { count },
    src: src || "page",
    inserted,
    updated,
    total
  });
  if (list.length > LOG_CAP) {
    list.splice(0, list.length - LOG_CAP);
  }

  // Her şeyi kaydet
  await chrome.storage.local.set({
    [KEY]:  list,
    [SKEY]: ag,
    [RKEY]: newRaw
  });
}

// Mesaj dinleyici
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  try {
    // İçeriğe injector.js’i enjekte et
    if (msg?.action === "injectMain" && sender.tab?.id) {
      chrome.scripting
        .executeScript({
          target: { tabId: sender.tab.id, allFrames: true },
          world: "MAIN",
          files: ["injector.js"]
        })
        .then(() => sendResponse({ ok: true }))
        .catch(e => sendResponse({ ok: false, error: String(e) }));
      return true; // async response
    }

    // Sayfadan gelen payload’ı işle
    if (msg?.action === "payloadFromPage" && msg.payload) {
      push(msg.payload, msg.src || "page");
    }
  } catch (e) {
    sendResponse?.({ ok: false, error: String(e) });
  }
});
